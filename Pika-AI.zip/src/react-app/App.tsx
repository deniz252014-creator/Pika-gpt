import ChatPage from "@/react-app/pages/Chat";

export default function App() {
  return <ChatPage />;
}

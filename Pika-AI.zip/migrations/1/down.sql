
DROP INDEX idx_chat_messages_created_at;
DROP INDEX idx_chat_messages_user_id;
DROP TABLE chat_messages;


DROP INDEX idx_user_profiles_user_id;
DROP TABLE user_profiles;
